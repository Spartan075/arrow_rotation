# CHANGELOG


## [1.0.6] 2020-06-21

### BUGFIXES
- corrected issue with actors not being associated with tokens


## [1.0.5] 2020-06-18

### ADDED
- Vertical and Horizontal flip token options (doesn't work with Indicators)
- Added larger indicator option
- Backend support for multiple graphics indicators

## [1.0.3] 2020-06-18

### BUGFIXES

## [1.0.2] 2020-06-18

### BUGFIXES

## [1.0.1] 2020-06-18

### ADDED
- Indicators to show facing direction
- Indicator Options
- Ability to change direction w/o moving using SHIFT.



## [1.0.0] 2020-06-13

### ADDED

- Initial Release
- Tokens rotate "facing" based on movement